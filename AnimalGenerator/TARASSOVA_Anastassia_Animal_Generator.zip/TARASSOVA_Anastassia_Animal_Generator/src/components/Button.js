export default function Button ({ onClick }) {

// if button clicked, generate an animal
return <button onClick={onClick}>Generate an animal</button>

}