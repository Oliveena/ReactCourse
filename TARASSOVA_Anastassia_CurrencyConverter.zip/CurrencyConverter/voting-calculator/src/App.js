import './App.css';
import VoteCalculator from './components/VoteCalculator';

function App() {
return (
  <div>
    <VoteCalculator />
  </div>

);
}

export default App;
