import React from "react";

export default function Intro() {
  return <h1 className="text-white">Welcome! Ana does her homework.</h1>;
}
